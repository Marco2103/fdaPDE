// make core variable symbols visibile to Rcpp
#include <fdaPDE/Core.h>
