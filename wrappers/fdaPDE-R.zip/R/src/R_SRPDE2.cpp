// // we only include RcppEigen.h which pulls Rcpp.h in for us
// #include <RcppEigen.h>
// // [[Rcpp::depends(RcppEigen)]]

// #include <fdaPDE/core/utils/Symbols.h>
// #include <fdaPDE/models/regression/SRPDE.h>
// using fdaPDE::models::SRPDE;
// #include <fdaPDE/models/SamplingDesign.h>
// using fdaPDE::models::Sampling;
